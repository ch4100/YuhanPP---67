document.getElementById('getDataButton').addEventListener('click', fetchData);

function fetchData() {
    fetch('http://localhost:3000/hi')
        .then(response => response.text())
        .then(data => {
            document.getElementById('result').textContent = data;
        })
        .catch(error => {
            console.error('데이터를 가져오는 중 오류가 발생했습니다:', error);
        });
}